package com.example.atry;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView Humidity = findViewById(R.id.humidity_TextView);
        TextView SoilHumidity = findViewById(R.id.soilhumidity_TextView);
        TextView Temperature = findViewById(R.id.temperature_TextView);
        TextView Rain = findViewById(R.id.Rain_TextView);
        Button ON_btn = findViewById(R.id.progress_btn);
        ProgressBar humidity_progress = findViewById(R.id.humidity_progress);
        ProgressBar temperature_progress = findViewById(R.id.temperature_progress);
        ProgressBar SoilHumidity_progress = findViewById(R.id.Soilhumidity_progress);
        ProgressBar rain_progress = findViewById(R.id.rain_progress);
    }
}